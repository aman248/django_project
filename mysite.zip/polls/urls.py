from django.urls import path
from . import views
app_name = 'polls'
urlpatterns = [
    path('polls',views.index,name = 'index'),
    path('<int:question_id>/',views.d,name='d'),
    path('h/',views.h,name='aman'),
    path('<int:question_id>/results',views.results,name='results'),
    path('<int:question_id>/vote',views.vote,name='vote')
    

]
