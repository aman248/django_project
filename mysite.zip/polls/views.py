from django.shortcuts import render,get_object_or_404
from django.http import HttpResponse,HttpResponseRedirect
from .models import Choice,Question
from django.urls import reverse

# Create your views here.
def index(request):

    questions = Question.objects.all()
    return render(request,'home.html',{'questions':questions})

def d(request,question_id):
    question = get_object_or_404(Question,pk=question_id)
    context = {'question':question}
    return render(request,'details.html',context=context)

def vote(request, question_id):
    question = get_object_or_404(Question, pk=question_id)
    try:
        selected_choice = question.choice_set.get(pk=request.POST['choice'])
    except (KeyError):
        # Redisplay the question voting form.
        return render(request, 'details.html', {
            'question': question,
            'error_message': "You didn't select a choice.",
        })
    else:
        selected_choice.vote += 1
        selected_choice.save()
        # Always return an HttpResponseRedirect after successfully dealing
        # with POST data. This prevents data from being posted twice if a
        # user hits the Back button.
        #return HttpResponse("i am aman")
        questio = get_object_or_404(Question, pk=question_id)
        print('this line !@#$' + reverse('polls:results', args=(question.id,)))
        #return render(request, 'results.html', {'question': questio})
        return HttpResponseRedirect(reverse('polls:results', args=(question.id,)))

def results(request,question_id):
    question = get_object_or_404(Question,pk=question_id)   
    return render(request,'results.html',{'question':question})

def h(request):
    
    return render(request,'h.html')      
        

    




